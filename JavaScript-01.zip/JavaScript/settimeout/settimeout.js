console.log('start')

setTimeout(function(){
    console.log('ABC');
},3000)

console.log('end')