// window object (BOM) (global object)
console.log(window);
// details about history of the application 
// (back() & forward())
console.log(window.history);
// details about the url 
// to get the url details or modify the url details
console.log(window.location);
// document represents the web page
console.log(window.document);
// geolocation of the system
console.log(window.navigator);
console.log('---------------------------------');
console.log(history);
console.log(location);
console.log(document);
console.log(navigator);

console.log('------------------------------');

// window.alert('Hi')
// alert('Welcome')

// const isAdult = confirm('Are you adult ?')
// console.log('isAdult', isAdult);

// const age = prompt('What is your age ?')
// console.log('Age', age);

window.console.log('I belong to window object')
console.log('--------------------------');
